import os
import tempfile

import pytest
from flask import json

import flaskr


@pytest.fixture
def client():
    app = flaskr.create_app()
    db_fd, app.config['DATABASE'] = tempfile.mkstemp()
    app.config['TESTING'] = True

    with app.test_client() as client:
        with app.app_context():
            flaskr.db.init_db("schema.sql")
        yield client

    os.close(db_fd)
    os.unlink(app.config['DATABASE'])


def test_get_message(client):
    """Start with a blank database."""
    rv = client.get('/api/GetMessage?application_id=4')
    assert b"sorry but there isn't message' in rv.data"
    mimetype = 'application/json'
    headers = {
        'Content-Type': mimetype,
        'Accept': mimetype
    }
    data = {
        "application_id": 4,
        "session_id": "aaaa",
        "message_id": "bb",
        "participants": ["jhjjjj", "dfghj"],
        "content": "Hi, how are you today?"
    }
    url = '/api/AddMessage'

    response = client.post(url, data=json.dumps(data), headers=headers)
    assert b'succeeded' in response.data
    rv = client.get('/api/GetMessage')
    assert b'This arg is not supported' in rv.data
    rv = client.get('api/GetMessage?aplication_id=4')
    assert b'This arg is not supported' in rv.data
    rv=client.get('api/GetMessage?message_id=bb')
    assert 'Hi, how are you today?' in rv.json.get("content")
    mimetype = 'application/json'
    headers = {
        'Content-Type': mimetype,
        'Accept': mimetype
    }
    data = {
        "application_id": 4,
        "session_id": "bbbb",
        "message_id": "cc",
        "participants": ["jhjjjj", "dfghj"],
        "content": "Hi, how are you tomorrow?"
    }
    url = '/api/AddMessage'

    response = client.post(url, data=json.dumps(data), headers=headers)
    assert b'succeeded' in response.data
    rv = client.get('api/GetMessage?application_id=4')
    assert len(rv.json) == 2


def test_add_message(client):
    mimetype = 'application/json'
    headers = {
        'Content-Type': mimetype,
        'Accept': mimetype
    }
    data = {
        "application_id": 4,
        "session_id": "aaaa",
        "message_id": "tt",
        "participants": ["jhjjjj", "dfghj"],
        "content": "Hi, how are you today?"
    }
    url = '/api/AddMessage'

    response = client.post(url, data=json.dumps(data), headers=headers)
    assert b'succeeded' in response.data
    response = client.post(url, data=json.dumps(data), headers=headers)
    assert b'sorry but it exists' in response.data
    mimetype = 'application/json'
    headers = {
        'Content-Type': mimetype,
        'Accept': mimetype
    }
    data = {
        "application_id": "4",
        "session_id": "bbbb",
        "message_id": "yy",
        "participants": ["jhjjjj", "dfghj"],
        "content": "Hi, how are you tomorrow?"
    }
    url = '/api/AddMessage'

    response = client.post(url, data=json.dumps(data), headers=headers)
    assert b'the type of application_id is not valid' in response.data


def test_delete_message(client):
    rv = client.delete('/api/DeleteMessage')
    assert b'This arg is not supported' in rv.data
    rv = client.delete('/api/DeleteMessage?aplication=1')
    assert b'This arg is not supported' in rv.data
    rv = client.get('/api/GetMessage?application_id=4')
    assert b"sorry but there isn't message' in rv.data"
    mimetype = 'application/json'
    headers = {
        'Content-Type': mimetype,
        'Accept': mimetype
    }
    data = {
        "application_id": 4,
        "session_id": "bbbb",
        "message_id": "dd",
        "participants": ["jhjjjj", "dfghj"],
        "content": "Hi, how are you tomorrow?"
    }
    url = '/api/AddMessage'

    response = client.post(url, data=json.dumps(data), headers=headers)
    assert b'succeeded' in response.data
    rv = client.get('api/GetMessage?application_id=4')
    assert len(rv.json) == 1
    rv = client.delete('api/DeleteMessage?application_id=4')
    assert b'succeeded' in rv.data
    rv = client.get('/api/GetMessage?application_id=4')
    assert b"sorry but there isn't message' in rv.data"

This api app is for manage messages

the data is saved to sqlite3

in all the request - url is :http://localhost:5000/api

the app has rest api to getMessage,addMessage and deleteMessage

addMessage-  the api take the data from the client and insert into Messages table after check if the data is valid and if this data is not exist

getMessage - the api get list messages single message from Messages table

deleteMessage - the api delete message from Messages table

  


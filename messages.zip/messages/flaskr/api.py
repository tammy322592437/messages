from flaskr import db

from flask import (
    Blueprint, request, jsonify
)

bp = Blueprint('api', __name__, url_prefix='/api')


def query_db(query, args=(), one=False):
    cur = db.get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if one else rv


def use_db(query, arg=()):
    conn = db.get_db()
    curs = conn.cursor()
    curs.execute(query, arg)
    conn.commit()
    curs.close()


def get_message_from_db(args):
    if "application_id" in args:
        return query_db("select * from Messages where application_id= '%s'" % args["application_id"])
    elif "session_id" in args:
        return query_db("select * from Messages where session_id= '%s'" % args["session_id"])
    elif "message_id" in args:
        message = query_db("select * from Messages where message_id= '%s'" % args["message_id"])
        if message:
            return message[0]
        else:
            return message
    return 'This arg is not supported'


def add_message_to_db(mess):
    use_db(
        'insert into Messages (application_id, session_id, message_id, participants, content) values (?,?,?,?,?)',
        (
            mess.application_id,
            mess.session_id,
            mess.message_id,
            mess.participants,
            mess.content
        )
    )
    return "succeeded"


def make_object_message(args):
    participants_list = []
    for message in args.get("participants"):
        participants_list.append(message)
    return Message(
        application_id=args.get("application_id"),
        session_id=args.get("session_id"),
        message_id=args.get("message_id"),
        participants=str(participants_list),
        content=args.get("content")
    )


def valid_message(args):
    if type(args.get("application_id")) is not int:
        return "the type of application_id is not valid"
    if type(args.get("session_id")) is not str:
        return "the type of session_id is not valid"
    if type(args.get("message_id")) is not str:
        return "the type of message_id is not valid"
    if type(args.get("participants")) is not list:
        return "the type of participants is not valid"
    if type(args.get("participants")) is not list:
        for message in args.get("participants"):
            if type(message) is not str:
                return "the type of participants is not valid"
    if type(args.get("content")) is not str:
        return "the type of content is not valid"
    return make_object_message(args)

@bp.route('/')
def hello_world():
    return 'my_messages'


@bp.route('/GetMessage', methods=['GET'])
def get_message():
    response = get_message_from_db(request.args)
    if not response:
        return "sorry but there isn't message with this route"
    elif response == "This arg is not supported":
        return response
    return jsonify(response)


@bp.route('/AddMessage', methods=['POST'])
def add_message():
    mess = valid_message(request.get_json())
    if type(mess) != Message:
        return mess
    message = query_db("select * from Messages where message_id = '%s'" % mess.message_id)
    if message:
        return "sorry but it exists"
    return add_message_to_db(mess)


@bp.route('/DeleteMessage', methods=['DELETE'])
def delete_message():
    if "application_id" in request.args:
        use_db('delete  from messages where application_id= "%s"' % request.args["application_id"])
    elif "session_id" in request.args:
        use_db('delete  from messages where session_id= "%s"' % request.args["session_id"])
    elif "message_id" in request.args:
        use_db('delete  from messages where message_id= "%s"' % request.args["message_id"])
    else:
        return "This arg is not supported"
    return "succeeded"


class Message:
    def __init__(self, application_id, session_id, message_id, participants, content):
        self.application_id = application_id
        self.session_id = session_id
        self.message_id = message_id
        self.participants = participants
        self.content = content

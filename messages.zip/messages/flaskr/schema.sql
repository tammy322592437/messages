DROP TABLE "Messages";

CREATE TABLE "Messages" (
	"application_id"	INTEGER NOT NULL,
	"session_id"	TEXT NOT NULL,
	"message_id"	TEXT NOT NULL UNIQUE,
	"participants"	TEXT NOT NULL,
	"content"	TEXT NOT NULL,
	PRIMARY KEY("message_id")
)